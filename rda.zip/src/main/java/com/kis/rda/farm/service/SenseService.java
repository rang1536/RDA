package com.kis.rda.farm.service;							
import java.util.ArrayList;
import java.util.HashMap;							
import java.util.List;							
import java.util.Map;							
							
import org.springframework.beans.factory.annotation.Autowired;							
import org.springframework.stereotype.Service;

import com.kis.rda.common.domain.Sense;
import com.kis.rda.common.domain.TbSensetime;
import com.kis.rda.farm.dao.SenseDao;
import com.kis.rda.farm.domain.Aduino;
import com.kis.rda.farm.domain.Cbcentity;
import com.kis.rda.farm.domain.EntityList;
import com.kis.rda.farm.domain.Farm;							
import com.kis.rda.farm.domain.NewFarm;
import com.kis.rda.farm.domain.TbSenseCount;
import com.kis.rda.farm.domain.TbSenseEntityList;
import com.kis.rda.farm.domain.TbSenseEntityListDetail;
import com.kis.rda.farm.domain.TbsenseStableList;
import com.kis.rda.util.Paging;							
import com.kis.rda.util.UtilPaging;							
							
@Service							
public class SenseService {							
								
	@Autowired							
	private SenseDao senseDao;							
	 
	public Map<String, Object> ajaxsenseEntityList() {
		Map<String, Object> map = new HashMap<String, Object>();		
		List<TbSenseEntityList> ajaxList = senseDao.ajaxsenseEntityList();		
		map.put("ajaxList",ajaxList);		
		return map;
	}
	public Map<String, Object> ajaxsenseStableList() {
		Map<String, Object> map = new HashMap<String, Object>();		
		List<TbsenseStableList> ajaxList = senseDao.ajaxsenseStableList();		
		map.put("ajaxList",ajaxList);		
		return map;
	}
	public Map<String, Object> ajaxsenseEntityListDetail(TbSenseEntityListDetail entityDetail) {
		Map<String, Object> map = new HashMap<String, Object>();		
		System.out.println("목장getSENSENODEID"+ entityDetail.getNODEID());		
		List<TbSenseEntityListDetail> ajaxList = senseDao.ajaxsenseEntityListDetail(entityDetail);		
		map.put("ajaxList",ajaxList);		
		return map;
	}
	public Map<String, Object> ajaxsenseStableListDetail(TbsenseStableList entityDetail) {
		Map<String, Object> map = new HashMap<String, Object>();	
		System.out.println("목장getSENSENODEID"+ entityDetail.getSENSENODEID());		
		List<TbsenseStableList> ajaxList = senseDao.ajaxsenseStableListDetail(entityDetail);		
		map.put("ajaxList",ajaxList);		
		return map;				
	}
	public int ajaxsenseStableEntityInsertDo(Sense entityInsert) {
		 int result = senseDao.ajaxsenseStableEntityInsertDo(entityInsert);		
			return result;		
		}
	
	
	public Map<String, Object> selectchartymd(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		List<String> chartymd = senseDao.selectchartymd(map);
		map.put("chartymd", chartymd);
		return map;
	}
	
	public Map<String, Object> selectchartavg(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		List<String> chartavg = senseDao.selectchartavg(map);
		map.put("chartavg", chartavg);
		return map;
	}
	public Map<String, Object> selectchartcentr(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		List<String> chartcentr = senseDao.selectchartcentr(map);
		map.put("chartcentr", chartcentr);
		return map;
	}
	public Map<String, Object> selectupdown(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		List<String> chartupdown = senseDao.selectupdown(map);
		map.put("chartupdown", chartupdown);
		return map;
	}
	
	
	
	public Map<String, Object> selectStablechartymd(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		List<String> chartymd = senseDao.selectStablechartymd(map);
		map.put("chartymd", chartymd);
		return map;
	}
	 
	public Map<String, Object> selectStablechartavg(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		
		List<String> chartavg = senseDao.selectStablechartavg(map);
		map.put("chartavg", chartavg);
		return map;
	}
	public Map<String, Object> selectStablechartavg2(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		
		List<String> chartavg2 = senseDao.selectStablechartavg2(map);
		map.put("chartavg2", chartavg2);
		return map;
	}
	public Map<String, Object> selectStablechartavg3(String nodeId) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("nodeId", nodeId);
		
		List<String> chartavg3 = senseDao.selectStablechartavg3(map);
		map.put("chartavg3", chartavg3);
		return map;
	}

	//아두이노
	public List<Aduino> readAduinoSensingServ(){
		return senseDao.selectAduinoSensing();
	}
	
	//날짜목록조회
	/*public List<String> readDateListServ(){
		List<Map<String,String>> result = senseDao.selectDateList();
		List<String> dateList = new ArrayList<String>();
		
		for(int i=0; i<result.size(); i++) {
			String date = "'17."+result.get(i).get("DAY").toString()+"'";
			dateList.add(date);	
		}
		
		return dateList;
	}*/
	//개체별 일일활동량 조회
	public List<List<String>> readEntityActiveServ(){
		List<String> acList; //개체별 활동량 목록
		List<List<String>> list = new ArrayList<List<String>>(); // 목록을 담은 목록
		String activeValue ="";
		//날짜목록, 개체수, 
		
		
		
		//개체
		String[] nodeId = {"201710130001","201710130002","201710130003","201710130004","201710130005","201710130006","201710130007","201710130008","201710130009","201710130010"};
		
		for(int i=0; i<nodeId.length; i++) {
			List<Map<String,String>> activeList = senseDao.selectEntityActive(nodeId[i]); //날짜,활동량 조회
			acList = new ArrayList<String>();
			for(int j=0; j<activeList.size(); j++) {
				activeValue = String.valueOf(activeList.get(i).get("ACTION_VALUE")); //활동량만 추출
				acList.add(activeValue);
			}
			list.add(acList);
		}
		return list;
	}
	
	//현황 > 개체별 일일활동량 카운트 조회
	public List<Map<String, Object>> readEntityActiveCountServ(){
		List<String> dateList = new ArrayList<String>();
		Map<String, Object> map = null;
		List<Map<String, Object>> ajaxList = new ArrayList<Map<String, Object>>();
		List<Integer> cow1,cow2,cow3,cow4,cow5,cow6,cow7,cow8,cow9,cow10;
		//개체
		cow1 = senseDao.selectEntityActiveCount("201710130001");
		cow2 = senseDao.selectEntityActiveCount("201710130002");
		cow3 = senseDao.selectEntityActiveCount("201710130003");
		cow4 = senseDao.selectEntityActiveCount("201710130004");
		cow5 = senseDao.selectEntityActiveCount("201710130005");
		cow6 = senseDao.selectEntityActiveCount("201710130006");
		cow7 = senseDao.selectEntityActiveCount("201710130007");
		cow8 = senseDao.selectEntityActiveCount("201710130008");
		cow9 = senseDao.selectEntityActiveCount("201710130009");
		cow10 = senseDao.selectEntityActiveCount("201710130010");
		
		dateList = senseDao.selectDateList("201710130001");
		
		for(int i=0; i<dateList.size(); i++) {
			map = new HashMap<String, Object>();
			map.put("day", dateList.get(i));
			map.put("cow1", cow1.get(i));
			map.put("cow2", cow2.get(i));
			map.put("cow3", cow3.get(i));
			map.put("cow4", cow4.get(i));
			map.put("cow5", cow5.get(i));
			map.put("cow6", cow6.get(i));
			map.put("cow7", cow7.get(i));
			map.put("cow8", cow8.get(i));
			map.put("cow9", cow9.get(i));
			map.put("cow10", cow10.get(i));
			ajaxList.add(map);
		}
		
		System.out.println(ajaxList);
		/*System.out.println("날짜목록 : "+dateList);
		System.out.println("카운트 목록 : "+activeCountList);*/
		
		/*map.put("dateList", dateList);
		map.put("activeCountList", activeCountList);*/
		
		return ajaxList;
	}
}						
