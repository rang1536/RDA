package com.kis.rda.farm.domain;

import com.kis.rda.common.domain.Survey;

public class QuResearch extends Survey {


	 
	private String	mod	;
	private	String	Q_DATE1	;
	private	String	Q_DATE2	;
	private	String	Q_DATE3	;
	
	
	public String getMod() {
		return mod;
	}
	public void setMod(String mod) {
		this.mod = mod;
	}
	public String getQ_DATE1() {
		return Q_DATE1;
	}
	public void setQ_DATE1(String q_DATE1) {
		Q_DATE1 = q_DATE1;
	}
	public String getQ_DATE2() {
		return Q_DATE2;
	}
	public void setQ_DATE2(String q_DATE2) {
		Q_DATE2 = q_DATE2;
	}
	public String getQ_DATE3() {
		return Q_DATE3;
	}
	public void setQ_DATE3(String q_DATE3) {
		Q_DATE3 = q_DATE3;
	}
 
 
 

	
	
	
	
}
