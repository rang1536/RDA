package com.kis.rda.farm.domain;

public class Aduino {
	private int gAx;
	private int gAy;
	private int gAz;
	private int gGx;
	private int gGy;
	private int gGz;
	private int gMx;
	private int gMy;
	private int gMz;
	private float gTemper;
	private float gHumi;
	private int gActive;
	private String gDate;
	private String gFarm;
	private String gSensorId;
	public int getgAx() {
		return gAx;
	}
	public void setgAx(int gAx) {
		this.gAx = gAx;
	}
	public int getgAy() {
		return gAy;
	}
	public void setgAy(int gAy) {
		this.gAy = gAy;
	}
	public int getgAz() {
		return gAz;
	}
	public void setgAz(int gAz) {
		this.gAz = gAz;
	}
	public int getgGx() {
		return gGx;
	}
	public void setgGx(int gGx) {
		this.gGx = gGx;
	}
	public int getgGy() {
		return gGy;
	}
	public void setgGy(int gGy) {
		this.gGy = gGy;
	}
	public int getgGz() {
		return gGz;
	}
	public void setgGz(int gGz) {
		this.gGz = gGz;
	}
	public int getgMx() {
		return gMx;
	}
	public void setgMx(int gMx) {
		this.gMx = gMx;
	}
	public int getgMy() {
		return gMy;
	}
	public void setgMy(int gMy) {
		this.gMy = gMy;
	}
	public int getgMz() {
		return gMz;
	}
	public void setgMz(int gMz) {
		this.gMz = gMz;
	}
	public float getgTemper() {
		return gTemper;
	}
	public void setgTemper(float gTemper) {
		this.gTemper = gTemper;
	}
	public float getgHumi() {
		return gHumi;
	}
	public void setgHumi(float gHumi) {
		this.gHumi = gHumi;
	}
	public int getgActive() {
		return gActive;
	}
	public void setgActive(int gActive) {
		this.gActive = gActive;
	}
	public String getgDate() {
		return gDate;
	}
	public void setgDate(String gDate) {
		this.gDate = gDate;
	}
	public String getgFarm() {
		return gFarm;
	}
	public void setgFarm(String gFarm) {
		this.gFarm = gFarm;
	}
	public String getgSensorId() {
		return gSensorId;
	}
	public void setgSensorId(String gSensorId) {
		this.gSensorId = gSensorId;
	}
	@Override
	public String toString() {
		return "Aduino [gAx=" + gAx + ", gAy=" + gAy + ", gAz=" + gAz + ", gGx=" + gGx + ", gGy=" + gGy + ", gGz=" + gGz
				+ ", gMx=" + gMx + ", gMy=" + gMy + ", gMz=" + gMz + ", gTemper=" + gTemper + ", gHumi=" + gHumi
				+ ", gActive=" + gActive + ", gDate=" + gDate + ", gFarm=" + gFarm + ", gSensorId=" + gSensorId + "]";
	}
	
	
}
