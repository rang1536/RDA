package com.kis.rda.farm.domain;

import com.kis.rda.common.domain.TbSense;
import com.kis.rda.common.domain.TbSenseEnv;

public class TbSenseEntityListDetail extends TbSense  {
	private	String	RNUM	;

	public String getRNUM() {
		return RNUM;
	}

	public void setRNUM(String rNUM) {
		RNUM = rNUM;
	}
	
}
