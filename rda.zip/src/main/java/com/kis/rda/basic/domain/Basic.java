package com.kis.rda.basic.domain;

public class Basic {

}
