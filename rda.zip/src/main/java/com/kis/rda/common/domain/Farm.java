package com.kis.rda.common.domain;

public class Farm {
	private String FARM_ID;
	private String ADDRESS;
	private String LOCATION;
	private String FNAME;
	private String PHONE1;
	private String EMAIL;
	private String KC;
	private String MC;
	private String CALF;
	private String HP1;
	private String NAME;
	private String PHONE2;
	private String PHONE3;
	private String HP2;
	private String HP3;
	private String INPUTDATE;
	private String UPDATEDATE;
	private String CU_ID;
	private String SEQNO;

	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getFARM_ID() {
		return FARM_ID;
	}

	public void setFARM_ID(String fARM_ID) {
		FARM_ID = fARM_ID;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}

	public String getLOCATION() {
		return LOCATION;
	}

	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}

	public String getFNAME() {
		return FNAME;
	}

	public void setFNAME(String fNAME) {
		FNAME = fNAME;
	}

	public String getPHONE1() {
		return PHONE1;
	}

	public void setPHONE1(String pHONE1) {
		PHONE1 = pHONE1;
	}

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	public String getKC() {
		return KC;
	}

	public void setKC(String kC) {
		KC = kC;
	}

	public String getMC() {
		return MC;
	}

	public void setMC(String mC) {
		MC = mC;
	}

	public String getCALF() {
		return CALF;
	}

	public void setCALF(String cALF) {
		CALF = cALF;
	}

	public String getHP1() {
		return HP1;
	}

	public void setHP1(String hP1) {
		HP1 = hP1;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getPHONE2() {
		return PHONE2;
	}

	public void setPHONE2(String pHONE2) {
		PHONE2 = pHONE2;
	}

	public String getPHONE3() {
		return PHONE3;
	}

	public void setPHONE3(String pHONE3) {
		PHONE3 = pHONE3;
	}

	public String getHP2() {
		return HP2;
	}

	public void setHP2(String hP2) {
		HP2 = hP2;
	}

	public String getHP3() {
		return HP3;
	}

	public void setHP3(String hP3) {
		HP3 = hP3;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getUPDATEDATE() {
		return UPDATEDATE;
	}

	public void setUPDATEDATE(String uPDATEDATE) {
		UPDATEDATE = uPDATEDATE;
	}

	public String getCU_ID() {
		return CU_ID;
	}

	public void setCU_ID(String cU_ID) {
		CU_ID = cU_ID;
	}

}
