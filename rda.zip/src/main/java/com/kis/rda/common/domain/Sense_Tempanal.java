package com.kis.rda.common.domain;

public class Sense_Tempanal {
	private String FARM_ID;
	private String CU_ID;
	private String ENTITY_ID;
	private String YEAR;
	private String MONTH;
	private String DAY;
	private String ST_AVR;
	private String ST_STDEV;
	private String ST_MIN;
	private String ST_MAX;
	private String INPUTDATE;
	private String NUM;
	private String SEQNO;

	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getFARM_ID() {
		return FARM_ID;
	}

	public void setFARM_ID(String fARM_ID) {
		FARM_ID = fARM_ID;
	}

	public String getCU_ID() {
		return CU_ID;
	}

	public void setCU_ID(String cU_ID) {
		CU_ID = cU_ID;
	}

	public String getENTITY_ID() {
		return ENTITY_ID;
	}

	public void setENTITY_ID(String eNTITY_ID) {
		ENTITY_ID = eNTITY_ID;
	}

	public String getYEAR() {
		return YEAR;
	}

	public void setYEAR(String yEAR) {
		YEAR = yEAR;
	}

	public String getMONTH() {
		return MONTH;
	}

	public void setMONTH(String mONTH) {
		MONTH = mONTH;
	}

	public String getDAY() {
		return DAY;
	}

	public void setDAY(String dAY) {
		DAY = dAY;
	}

	public String getST_AVR() {
		return ST_AVR;
	}

	public void setST_AVR(String sT_AVR) {
		ST_AVR = sT_AVR;
	}

	public String getST_STDEV() {
		return ST_STDEV;
	}

	public void setST_STDEV(String sT_STDEV) {
		ST_STDEV = sT_STDEV;
	}

	public String getST_MIN() {
		return ST_MIN;
	}

	public void setST_MIN(String sT_MIN) {
		ST_MIN = sT_MIN;
	}

	public String getST_MAX() {
		return ST_MAX;
	}

	public void setST_MAX(String sT_MAX) {
		ST_MAX = sT_MAX;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getNUM() {
		return NUM;
	}

	public void setNUM(String nUM) {
		NUM = nUM;
	}

}
