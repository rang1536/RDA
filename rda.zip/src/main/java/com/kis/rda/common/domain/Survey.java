package com.kis.rda.common.domain;

public class Survey {
	private String Q1;
	private String Q2;
	private String Q3;
	private String Q4;
	private String Q5;
	private String Q6;
	private String Q7;
	private String Q8;
	private String Q9;
	private String Q10;
	private String Q11;
	private String Q12;
	private String Q13;
	private String Q14;
	private String Q15;
	private String Q16;
	private String Q17;
	private String Q18;
	private String Q19;
	private String Q20;
	private String Q21;
	private String Q22;
	private String Q23;
	private String Q24;
	private String Q25;
	private String Q26;
	private String Q27;
	private String INPUTDATE;
	private String Q_DATE;
	private String FNAME;
	private String NAME;
	private String SEQNO;
	private String	 totalDate;		
	private String	 ydate;		
	private String	 mdate;		
	private String	 ddate;		
//	private String	 	tdate;	
				
				
		public String getTotalDate() {		
		//totalDate=	ydate+"/"+mdate+"/"+ddate+"/"+tdate;	
			totalDate=	ydate+"/"+mdate+"/"+ddate ;
		return totalDate;		
	}			
	public void setTotalDate(String totalDate) {			
		this.totalDate = totalDate;		
	}			
	public String getYdate() {			
		return ydate;		
	}			
	public void setYdate(String ydate) {			
		this.ydate = ydate;		
	}			
	public String getMdate() {			
		return mdate;		
	}			
	public void setMdate(String mdate) {			
		this.mdate = mdate;		
	}			
	public String getDdate() {			
		return ddate;		
	}			
	public void setDdate(String ddate) {			
		this.ddate = ddate;		
	}			
//	public String getTdate() {			
//		return tdate;		
//	}			
//	public void setTdate(String tdate) {			
//		this.tdate = tdate;		
//		}		
				

	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getQ1() {
		return Q1;
	}

	public void setQ1(String q1) {
		Q1 = q1;
	}

	public String getQ2() {
		return Q2;
	}

	public void setQ2(String q2) {
		Q2 = q2;
	}

	public String getQ3() {
		return Q3;
	}

	public void setQ3(String q3) {
		Q3 = q3;
	}

	public String getQ4() {
		return Q4;
	}

	public void setQ4(String q4) {
		Q4 = q4;
	}

	public String getQ5() {
		return Q5;
	}

	public void setQ5(String q5) {
		Q5 = q5;
	}

	public String getQ6() {
		return Q6;
	}

	public void setQ6(String q6) {
		Q6 = q6;
	}

	public String getQ7() {
		return Q7;
	}

	public void setQ7(String q7) {
		Q7 = q7;
	}

	public String getQ8() {
		return Q8;
	}

	public void setQ8(String q8) {
		Q8 = q8;
	}

	public String getQ9() {
		return Q9;
	}

	public void setQ9(String q9) {
		Q9 = q9;
	}

	public String getQ10() {
		return Q10;
	}

	public void setQ10(String q10) {
		Q10 = q10;
	}

	public String getQ11() {
		return Q11;
	}

	public void setQ11(String q11) {
		Q11 = q11;
	}

	public String getQ12() {
		return Q12;
	}

	public void setQ12(String q12) {
		Q12 = q12;
	}

	public String getQ13() {
		return Q13;
	}

	public void setQ13(String q13) {
		Q13 = q13;
	}

	public String getQ14() {
		return Q14;
	}

	public void setQ14(String q14) {
		Q14 = q14;
	}

	public String getQ15() {
		return Q15;
	}

	public void setQ15(String q15) {
		Q15 = q15;
	}

	public String getQ16() {
		return Q16;
	}

	public void setQ16(String q16) {
		Q16 = q16;
	}

	public String getQ17() {
		return Q17;
	}

	public void setQ17(String q17) {
		Q17 = q17;
	}

	public String getQ18() {
		return Q18;
	}

	public void setQ18(String q18) {
		Q18 = q18;
	}

	public String getQ19() {
		return Q19;
	}

	public void setQ19(String q19) {
		Q19 = q19;
	}

	public String getQ20() {
		return Q20;
	}

	public void setQ20(String q20) {
		Q20 = q20;
	}

	public String getQ21() {
		return Q21;
	}

	public void setQ21(String q21) {
		Q21 = q21;
	}

	public String getQ22() {
		return Q22;
	}

	public void setQ22(String q22) {
		Q22 = q22;
	}

	public String getQ23() {
		return Q23;
	}

	public void setQ23(String q23) {
		Q23 = q23;
	}

	public String getQ24() {
		return Q24;
	}

	public void setQ24(String q24) {
		Q24 = q24;
	}

	public String getQ25() {
		return Q25;
	}

	public void setQ25(String q25) {
		Q25 = q25;
	}

	public String getQ26() {
		return Q26;
	}

	public void setQ26(String q26) {
		Q26 = q26;
	}

	public String getQ27() {
		return Q27;
	}

	public void setQ27(String q27) {
		Q27 = q27;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getQ_DATE() {
		return Q_DATE;
	}

	public void setQ_DATE(String q_DATE) {
		Q_DATE = q_DATE;
	}

	public String getFNAME() {
		return FNAME;
	}

	public void setFNAME(String fNAME) {
		FNAME = fNAME;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

}
