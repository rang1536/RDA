package com.kis.rda.common.domain;

public class Sense {
	private String ENTITY_ID;
	private String ACTIVETIME;
	private String ACTIVELIVING;
	private String BODYTEMPER;
	private String EQUIPMENT;
	private String INPUTDATE;
	private String UPDATEDATE;
	private String SEQNO;

	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getENTITY_ID() {
		return ENTITY_ID;
	}

	public void setENTITY_ID(String eNTITY_ID) {
		ENTITY_ID = eNTITY_ID;
	}

	public String getACTIVETIME() {
		return ACTIVETIME;
	}

	public void setACTIVETIME(String aCTIVETIME) {
		ACTIVETIME = aCTIVETIME;
	}

	public String getACTIVELIVING() {
		return ACTIVELIVING;
	}

	public void setACTIVELIVING(String aCTIVELIVING) {
		ACTIVELIVING = aCTIVELIVING;
	}

	public String getBODYTEMPER() {
		return BODYTEMPER;
	}

	public void setBODYTEMPER(String bODYTEMPER) {
		BODYTEMPER = bODYTEMPER;
	}

	public String getEQUIPMENT() {
		return EQUIPMENT;
	}

	public void setEQUIPMENT(String eQUIPMENT) {
		EQUIPMENT = eQUIPMENT;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getUPDATEDATE() {
		return UPDATEDATE;
	}

	public void setUPDATEDATE(String uPDATEDATE) {
		UPDATEDATE = uPDATEDATE;
	}

}
