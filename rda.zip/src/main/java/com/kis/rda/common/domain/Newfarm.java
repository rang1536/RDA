package com.kis.rda.common.domain;

public class Newfarm {
	private String FARM_ID;
	private String FARM_NAME;
	private String ADDRESS;
	private String HP1;
	private String HP2;
	private String HP3;
	private String PHONE1;
	private String PHONE2;
	private String PHONE3;
	private String EMAIL;
	private String NAME;
	private String MC;
	private String CMONEY;
	private String CHC;
	private String CAREER;
	private String DIARRHEA;
	private String DIARRHEADO;
	private String CHCDIE;
	private String CHCYN;
	private String KMKC;
	private String KMPI;
	private String KMMC;
	private String KMETC;
	private String YEAR;
	private String DISINFECTANT;
	private String TEMP;
	private String HUMIDITY;
	private String ILLUMINANCE;
	private String WIND;
	private String JANITOR;
	private String VETERINARIAN;
	private String INPUTDATE;
	private String UPDATEDATE;
	private String CU_NUM;
	private String SEQNO;
	
	public String getADDRESS1() {
		return ADDRESS1;
	}

	public void setADDRESS1(String aDDRESS1) {
		ADDRESS1 = aDDRESS1;
	}

	public String getADDRESS2() {
		return ADDRESS2;
	}

	public void setADDRESS2(String aDDRESS2) {
		ADDRESS2 = aDDRESS2;
	}

	public String getADDRESS3() {
		return ADDRESS3;
	}

	public void setADDRESS3(String aDDRESS3) {
		ADDRESS3 = aDDRESS3;
	}

	private	String	ADDRESS1	;
	private	String	ADDRESS2	;
	private	String	ADDRESS3	;

	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getFARM_ID() {
		return FARM_ID;
	}

	public void setFARM_ID(String fARM_ID) {
		FARM_ID = fARM_ID;
	}

	public String getFARM_NAME() {
		return FARM_NAME;
	}

	public void setFARM_NAME(String fARM_NAME) {
		FARM_NAME = fARM_NAME;
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}

	public String getHP1() {
		return HP1;
	}

	public void setHP1(String hP1) {
		HP1 = hP1;
	}

	public String getHP2() {
		return HP2;
	}

	public void setHP2(String hP2) {
		HP2 = hP2;
	}

	public String getHP3() {
		return HP3;
	}

	public void setHP3(String hP3) {
		HP3 = hP3;
	}

	public String getPHONE1() {
		return PHONE1;
	}

	public void setPHONE1(String pHONE1) {
		PHONE1 = pHONE1;
	}

	public String getPHONE2() {
		return PHONE2;
	}

	public void setPHONE2(String pHONE2) {
		PHONE2 = pHONE2;
	}

	public String getPHONE3() {
		return PHONE3;
	}

	public void setPHONE3(String pHONE3) {
		PHONE3 = pHONE3;
	}

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	public String getNAME() {
		return NAME;
	}

	public void setNAME(String nAME) {
		NAME = nAME;
	}

	public String getMC() {
		return MC;
	}

	public void setMC(String mC) {
		MC = mC;
	}

	public String getCMONEY() {
		return CMONEY;
	}

	public void setCMONEY(String cMONEY) {
		CMONEY = cMONEY;
	}

	public String getCHC() {
		return CHC;
	}

	public void setCHC(String cHC) {
		CHC = cHC;
	}

	public String getCAREER() {
		return CAREER;
	}

	public void setCAREER(String cAREER) {
		CAREER = cAREER;
	}

	public String getDIARRHEA() {
		return DIARRHEA;
	}

	public void setDIARRHEA(String dIARRHEA) {
		DIARRHEA = dIARRHEA;
	}

	public String getDIARRHEADO() {
		return DIARRHEADO;
	}

	public void setDIARRHEADO(String dIARRHEADO) {
		DIARRHEADO = dIARRHEADO;
	}

	public String getCHCDIE() {
		return CHCDIE;
	}

	public void setCHCDIE(String cHCDIE) {
		CHCDIE = cHCDIE;
	}

	public String getCHCYN() {
		return CHCYN;
	}

	public void setCHCYN(String cHCYN) {
		CHCYN = cHCYN;
	}

	public String getKMKC() {
		return KMKC;
	}

	public void setKMKC(String kMKC) {
		KMKC = kMKC;
	}

	public String getKMPI() {
		return KMPI;
	}

	public void setKMPI(String kMPI) {
		KMPI = kMPI;
	}

	public String getKMMC() {
		return KMMC;
	}

	public void setKMMC(String kMMC) {
		KMMC = kMMC;
	}

	public String getKMETC() {
		return KMETC;
	}

	public void setKMETC(String kMETC) {
		KMETC = kMETC;
	}

	public String getYEAR() {
		return YEAR;
	}

	public void setYEAR(String yEAR) {
		YEAR = yEAR;
	}

	public String getDISINFECTANT() {
		return DISINFECTANT;
	}

	public void setDISINFECTANT(String dISINFECTANT) {
		DISINFECTANT = dISINFECTANT;
	}

	public String getTEMP() {
		return TEMP;
	}

	public void setTEMP(String tEMP) {
		TEMP = tEMP;
	}

	public String getHUMIDITY() {
		return HUMIDITY;
	}

	public void setHUMIDITY(String hUMIDITY) {
		HUMIDITY = hUMIDITY;
	}

	public String getILLUMINANCE() {
		return ILLUMINANCE;
	}

	public void setILLUMINANCE(String iLLUMINANCE) {
		ILLUMINANCE = iLLUMINANCE;
	}

	public String getWIND() {
		return WIND;
	}

	public void setWIND(String wIND) {
		WIND = wIND;
	}

	public String getJANITOR() {
		return JANITOR;
	}

	public void setJANITOR(String jANITOR) {
		JANITOR = jANITOR;
	}

	public String getVETERINARIAN() {
		return VETERINARIAN;
	}

	public void setVETERINARIAN(String vETERINARIAN) {
		VETERINARIAN = vETERINARIAN;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getUPDATEDATE() {
		return UPDATEDATE;
	}

	public void setUPDATEDATE(String uPDATEDATE) {
		UPDATEDATE = uPDATEDATE;
	}

	public String getCU_NUM() {
		return CU_NUM;
	}

	public void setCU_NUM(String cU_NUM) {
		CU_NUM = cU_NUM;
	}

}
