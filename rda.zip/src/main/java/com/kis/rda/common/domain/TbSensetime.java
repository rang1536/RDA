package com.kis.rda.common.domain;

public class TbSensetime {
	private	String	COW1	;
	private	String	COW2	;
	private	String	COW3	;
	private	String	COW4	;
	private	String	COW5	;
	private	String	COW6	;
	private	String	COW7	;
	private	String	COW8	;
	private	String	COW9	;
	private	String	COW10	;
	private	String	DTIME	;	
	private	String	NO	;
	
	
	public String getCOW1() {
		return COW1;
	}
	public void setCOW1(String cOW1) {
		COW1 = cOW1;
	}
	public String getCOW2() {
		return COW2;
	}
	public void setCOW2(String cOW2) {
		COW2 = cOW2;
	}
	public String getCOW3() {
		return COW3;
	}
	public void setCOW3(String cOW3) {
		COW3 = cOW3;
	}
	public String getCOW4() {
		return COW4;
	}
	public void setCOW4(String cOW4) {
		COW4 = cOW4;
	}
	public String getCOW5() {
		return COW5;
	}
	public void setCOW5(String cOW5) {
		COW5 = cOW5;
	}
	public String getCOW6() {
		return COW6;
	}
	public void setCOW6(String cOW6) {
		COW6 = cOW6;
	}
	public String getCOW7() {
		return COW7;
	}
	public void setCOW7(String cOW7) {
		COW7 = cOW7;
	}
	public String getCOW8() {
		return COW8;
	}
	public void setCOW8(String cOW8) {
		COW8 = cOW8;
	}
	public String getCOW9() {
		return COW9;
	}
	public void setCOW9(String cOW9) {
		COW9 = cOW9;
	}
	public String getCOW10() {
		return COW10;
	}
	public void setCOW10(String cOW10) {
		COW10 = cOW10;
	}
	public String getDTIME() {
		return DTIME;
	}
	public void setDTIME(String dTIME) {
		DTIME = dTIME;
	}

}
