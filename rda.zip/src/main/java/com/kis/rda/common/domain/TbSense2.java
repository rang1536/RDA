package com.kis.rda.common.domain;

public class TbSense2 {
	private	String	CU_ID	;
	private	String	NODE_ID	;
	private	String	ACTION_VALUE	;
	private	String	DEV_TYPE	;
	private	String	DTIME	;
	public String getCU_ID() {
		return CU_ID;
	}
	public void setCU_ID(String cU_ID) {
		CU_ID = cU_ID;
	}
	public String getNODE_ID() {
		return NODE_ID;
	}
	public void setNODE_ID(String nODE_ID) {
		NODE_ID = nODE_ID;
	}
	public String getACTION_VALUE() {
		return ACTION_VALUE;
	}
	public void setACTION_VALUE(String aCTION_VALUE) {
		ACTION_VALUE = aCTION_VALUE;
	}
	public String getDEV_TYPE() {
		return DEV_TYPE;
	}
	public void setDEV_TYPE(String dEV_TYPE) {
		DEV_TYPE = dEV_TYPE;
	}
	public String getDTIME() {
		return DTIME;
	}
	public void setDTIME(String dTIME) {
		DTIME = dTIME;
	}

}
