package com.kis.rda.common.domain;

public class Cbc {
	private String ENTITY_ID;
	private String CBC_GATHERDATE;
	private String RBC;
	private String HCT;
	private String HB;
	private String MCV;
	private String MCH;
	private String MCHC;
	private String RDW;
	private String RETIC1;
	private String RETIC2;
	private String WBC;
	private String NE1;
	private String LY1;
	private String MO1;
	private String EO1;
	private String BA1;
	private String NE2;
	private String LY2;
	private String MO2;
	private String EO2;
	private String BA2;
	private String PLT;
	private String MPV;
	private String PDW;
	private String PCT;
	private String FMM;
	private String EQUIPMENT;
	private String INPUTDATE;
	private String UPDATEDATE;
	private String PP;
	private String SP;
	private String SEQNO;

	
	private String	 totalDate;			
	private String	 ydate;			
	private String	 mdate;			
	private String	 ddate;			
	private String	 	tdate;		
	
	private String	 view_totalGathDate;					
	public String getView_totalGathDate() {	
		view_totalGathDate=	ydate+"년"+mdate+"월"+ddate+"일"+tdate+"시";	
		return view_totalGathDate;	
	}		
		public String getTotalDate() {			
		totalDate=	ydate+"/"+mdate+"/"+ddate+"/"+tdate;		
		return totalDate;			
	}		
		
		public void setCBC_GATHERDATE(String cBC_GATHERDATE) {
			String[] date = cBC_GATHERDATE.split("/"); 
			 if(date.length==1) {
					setYdate(date[0]);
			 }else if (date.length==2) {
				 setYdate(date[0]);
					setMdate(date[1]);
			 }else if (date.length==3) {
				 setYdate(date[0]);
					setMdate(date[1]);
					setDdate(date[2]);
			 }else if (date.length==4) {
					setYdate(date[0]);
					setMdate(date[1]);
					setDdate(date[2]);
					setTdate(date[3]);
			 }
			
			CBC_GATHERDATE = cBC_GATHERDATE;
		}
		
	public void setTotalDate(String totalDate) {				
		this.totalDate = totalDate;			
	}				
	public String getYdate() {				
		return ydate;			
	}				
	public void setYdate(String ydate) {				
		this.ydate = ydate;			
	}				
	public String getMdate() {				
		return mdate;			
	}				
	public void setMdate(String mdate) {				
		this.mdate = mdate;			
	}				
	public String getDdate() {				
		return ddate;			
	}				
	public void setDdate(String ddate) {				
		this.ddate = ddate;			
	}				
	public String getTdate() {				
		return tdate;			
	}				
	public void setTdate(String tdate) {				
		this.tdate = tdate;			
		}			

	
	public String getSEQNO() {
		return SEQNO;
	}

	public void setSEQNO(String sEQNO) {
		SEQNO = sEQNO;
	}

	public String getENTITY_ID() {
		return ENTITY_ID;
	}

	public void setENTITY_ID(String eNTITY_ID) {
		ENTITY_ID = eNTITY_ID;
	}

	public String getCBC_GATHERDATE() {
		return CBC_GATHERDATE;
	}

//	public void setCBC_GATHERDATE(String cBC_GATHERDATE) {
//		CBC_GATHERDATE = cBC_GATHERDATE;
//	}

	public String getRBC() {
		return RBC;
	}

	public void setRBC(String rBC) {
		RBC = rBC;
	}

	public String getHCT() {
		return HCT;
	}

	public void setHCT(String hCT) {
		HCT = hCT;
	}

	public String getHB() {
		return HB;
	}

	public void setHB(String hB) {
		HB = hB;
	}

	public String getMCV() {
		return MCV;
	}

	public void setMCV(String mCV) {
		MCV = mCV;
	}

	public String getMCH() {
		return MCH;
	}

	public void setMCH(String mCH) {
		MCH = mCH;
	}

	public String getMCHC() {
		return MCHC;
	}

	public void setMCHC(String mCHC) {
		MCHC = mCHC;
	}

	public String getRDW() {
		return RDW;
	}

	public void setRDW(String rDW) {
		RDW = rDW;
	}

	public String getRETIC1() {
		return RETIC1;
	}

	public void setRETIC1(String rETIC1) {
		RETIC1 = rETIC1;
	}

	public String getRETIC2() {
		return RETIC2;
	}

	public void setRETIC2(String rETIC2) {
		RETIC2 = rETIC2;
	}

	public String getWBC() {
		return WBC;
	}

	public void setWBC(String wBC) {
		WBC = wBC;
	}

	public String getNE1() {
		return NE1;
	}

	public void setNE1(String nE1) {
		NE1 = nE1;
	}

	public String getLY1() {
		return LY1;
	}

	public void setLY1(String lY1) {
		LY1 = lY1;
	}

	public String getMO1() {
		return MO1;
	}

	public void setMO1(String mO1) {
		MO1 = mO1;
	}

	public String getEO1() {
		return EO1;
	}

	public void setEO1(String eO1) {
		EO1 = eO1;
	}

	public String getBA1() {
		return BA1;
	}

	public void setBA1(String bA1) {
		BA1 = bA1;
	}

	public String getNE2() {
		return NE2;
	}

	public void setNE2(String nE2) {
		NE2 = nE2;
	}

	public String getLY2() {
		return LY2;
	}

	public void setLY2(String lY2) {
		LY2 = lY2;
	}

	public String getMO2() {
		return MO2;
	}

	public void setMO2(String mO2) {
		MO2 = mO2;
	}

	public String getEO2() {
		return EO2;
	}

	public void setEO2(String eO2) {
		EO2 = eO2;
	}

	public String getBA2() {
		return BA2;
	}

	public void setBA2(String bA2) {
		BA2 = bA2;
	}

	public String getPLT() {
		return PLT;
	}

	public void setPLT(String pLT) {
		PLT = pLT;
	}

	public String getMPV() {
		return MPV;
	}

	public void setMPV(String mPV) {
		MPV = mPV;
	}

	public String getPDW() {
		return PDW;
	}

	public void setPDW(String pDW) {
		PDW = pDW;
	}

	public String getPCT() {
		return PCT;
	}

	public void setPCT(String pCT) {
		PCT = pCT;
	}

	public String getFMM() {
		return FMM;
	}

	public void setFMM(String fMM) {
		FMM = fMM;
	}

	public String getEQUIPMENT() {
		return EQUIPMENT;
	}

	public void setEQUIPMENT(String eQUIPMENT) {
		EQUIPMENT = eQUIPMENT;
	}

	public String getINPUTDATE() {
		return INPUTDATE;
	}

	public void setINPUTDATE(String iNPUTDATE) {
		INPUTDATE = iNPUTDATE;
	}

	public String getUPDATEDATE() {
		return UPDATEDATE;
	}

	public void setUPDATEDATE(String uPDATEDATE) {
		UPDATEDATE = uPDATEDATE;
	}

	public String getPP() {
		return PP;
	}

	public void setPP(String pP) {
		PP = pP;
	}

	public String getSP() {
		return SP;
	}

	public void setSP(String sP) {
		SP = sP;
	}

}
