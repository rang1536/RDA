package com.kis.rda.feces.domain;

public class Feces {

}
